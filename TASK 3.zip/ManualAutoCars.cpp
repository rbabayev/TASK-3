﻿
#include <iostream>
#include <cassert>
#include <string>
using namespace std;

enum Fuel { ai92, ai95, ai98, hybrid, lpg, dizel };

class Car 
{

public:
    int _id;
    int _HP;
    Fuel _fuel;
    string _model;
    string _color;
    string _carNum;

    Car() {
    
        _HP = 0;
        _fuel = Fuel::dizel;
        _model = nullptr;
        _color = nullptr;
        _carNum = nullptr;

    }

    Car(string model, int hp, enum fuel, string color, string carNum) {
        static int id = 0;
        _id = ++id;
        _model = model;
        _HP = hp;
        _fuel;
        _color = color;
        _carNum = carNum;
    }

    void setModel(string model) {
        if (model.length() == 0) { 
            assert(!"Model bos buraxila bilmez !"); 
        }
        _model = model;
    }

    void setColor(string color) {
        if (color.length() == 0) {
            assert(!"Color bos buraxila bilmez !");
        }
        _color = color;
    }

    void setCarNum(string carNum) {
        if (carNum.length() == 0) {
            assert(!"Car number bos buraxila bilmez !");
        }
        _carNum = carNum;
    }

    void setFuel(Fuel fuel) {
        if (Fuel::dizel) { cout << " Dizel"; }
        else if (Fuel::hybrid) { cout << " Hybrid"; }
        else if (Fuel::lpg) { cout << " Lpg"; }
        else if (Fuel::ai92) { cout << " Ai92"; }
        else if (Fuel::ai95) { cout << " Ai95"; }
        else if (Fuel::ai98) { cout << " Ai98"; }
        else
            cout << "Fuel bos buraxila bilmez !!";
        _fuel = fuel;
    }
    
    void print() {
        cout << "+----------------------------------------------+" << endl;
        cout << "Id : " << _id << endl;
        cout << "HP : " << _HP << endl;
        cout << "Model : " << _model << endl;
        cout << "Color : " << _color << endl;
        cout << "Car Number : " << _carNum << endl;
        cout << "Fuel : " << setFuel << endl;
    }
};





class Manual : virtual public Car
{
public:
    int _gearCount;

    Manual() {
        _gearCount = 0;
    }

    Manual(int gearCount) {
        _gearCount = gearCount;
    }

    void print() {
        cout << "<== Manual Car ==>" << endl;
        Car::print();
        cout << "Gear Count : " << _gearCount << endl << endl;
    }

};


class Auto : virtual public Car
{
public:
    int _pedalCount;

    Auto() {
        _pedalCount = 2;
    }

    Auto(int pedalCount) {
        _pedalCount = pedalCount;
    }

    void print() {
        cout << "<== Auto Car ==>" << endl;
        Car::print();
        cout << "Pedal Count : " << _pedalCount << endl << endl;

    }

};


